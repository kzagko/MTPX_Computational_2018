#include <stdio.h>
#include "nrutil.h"

void InsertionSort(int*,int);
