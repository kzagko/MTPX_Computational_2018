#include <stdio.h>
#include "nrutil.h"

void SelectionSort(int*, int);
