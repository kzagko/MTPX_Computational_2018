#include<stdio.h>
#include "nrutil.h"

void MergeSort(int *, int);
void splitter(int *,int, int );
void merger(int *,int, int, int, int);
