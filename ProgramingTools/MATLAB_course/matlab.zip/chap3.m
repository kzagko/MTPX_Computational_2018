%Chapter 3
s1='Introduction to strings'
s2='Paragraph one'
length(s1)
s1(1)
s1(1:9)
s1(11:16)
a='numperr'
a(7)=[]
a(4)='b'
s2=s1*1
char(s2)
s1(11:16)'
s3=['part', ' ', 'one']
