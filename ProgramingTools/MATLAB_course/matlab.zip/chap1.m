%{ 
This is an M-file
%} 
echo on
%%
disp('****   PARAGRAPH 1.2   ****')
8-4
3*62
24/7
2^3.1
231/27.5
(2+3.7/6.5)/(3^3.6+1/3)
(3^3.6+1/3)\(2+3.7/6.5)
(2.8+5.9*i)/(37+71.2i)
(2.8+5.9*j)/(37+71.2j)
(2+5*i)^5/(3+11*i)^3
(2+3.7/6.5)/(3^3.6+1/3)
7>3
7<=4
2^3==8
3^2~=9
(2.6+1/3.3)*(37+i*82.6)/(23/47+7.3*i/73.9);

%%
disp('**********   PARAGRAPH 1.3   **********')
pi^2
pi*(2.5^2)
1/inf
1/0
0/0
inf/inf
realmax
realmin
x=2.1, y=7/3
z=x*y
x*y*sin(z)

%%
disp('*************   PARAGRAPH 1.4   ************')
sqrt(2)
sin(3.1)
acos(0.71)
tan(pi/4)
exp(1)
mod(23,5)
rand
rand
randn
randn
eps
eps(1)
eps(realmax)
eps(realmin)
eps(0)
sin(pi/7)
cos(2*pi/7)
tand(45)
sind(135)
log(2.2)
%%
disp('****   PARAGRAPH 1.6   ****')
(2+sqrt(11+3/7))...
/(3+sin(21/85))
(2+sqrt(11+3/7))/(3+sin(21/85))
2/3,4^2,1/6
%%
disp('****   PARAGRAPH 1.7   ****')
velocity=50;
travelingtime=60;
distance=velocity*travelingtime;
disp('distance= '),disp(distance)

%%
disp('****   PARAGRAPH 1.8   ****')
a=sqrt(2)
ceil(a)
floor(a)
fix(a)
round(a)
chop(a,3)